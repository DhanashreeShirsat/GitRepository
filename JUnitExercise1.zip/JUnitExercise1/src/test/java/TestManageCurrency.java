import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.training.Currency;
import com.training.ManageCurrency;

/**
 * 
 * @author d.shirsat
 * Test Class for ManageCurrency class
 *
 */
public class TestManageCurrency {

	Currency currency = new Currency();

	@BeforeClass
	public static void beforeClass() {
		System.out.println("BeforeClass");
	}
	
	@Before
	public void setUp() {
		System.out.println("Before");
	}
	
	@AfterClass
	public static void afterClass() {
		System.out.println("AfterClass");
	}
	
	@After
	public void tearDown() {
		System.out.println("After");
	}
	
	@Test
	public void testGetCurrencyDetailsStatusOk() {
		System.out.println("testGetCurrencyDetailsStatusOk");
		ManageCurrency manageCurrency = new ManageCurrency(currency);
		manageCurrency.gerCurrencyDetails(1);
		Assert.assertEquals("Status", "Ok", manageCurrency.getStatus());
	}
	
	@Test
	public void testGetCurrencyDetailsStatusNotOk() {
		System.out.println("testGetCurrencyDetailsStatusNotOk");
		ManageCurrency manageCurrency = new ManageCurrency(currency);
		manageCurrency.gerCurrencyDetails(3);
		Assert.assertEquals("Status", "Error", manageCurrency.getStatus());
	}
	
	@Test
	@Ignore
	public void testGetCurrencyDetailsStatusError() {
		System.out.println("testGetCurrencyDetailsStatusError");
		ManageCurrency manageCurrency = new ManageCurrency(currency);
		manageCurrency.gerCurrencyDetails(3);
		Assert.assertEquals("Status", "Error", manageCurrency.getStatus());
	} 
	
}
