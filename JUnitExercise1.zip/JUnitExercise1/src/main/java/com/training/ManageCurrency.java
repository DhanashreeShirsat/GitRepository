package com.training;

/**
 * Created by mchaurasia on 05-07-2016.
 */
public class ManageCurrency {

    private String status;
    Currency currency;

    public ManageCurrency(Currency currency){
        this.currency =  currency;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void gerCurrencyDetails(int value){
        switch(value) {
            case 1:
                currency.setName("Rupee");
                currency.setCountry("India");
                setStatus("Ok");
                break;
            case 2:
                currency.setName("Dollar");
                currency.setCountry("USA");
                setStatus("Ok");
                break;
            default :
                currency.setName("unknown");
                currency.setCountry("unknown");
                setStatus("Error");
        }
    }
}
